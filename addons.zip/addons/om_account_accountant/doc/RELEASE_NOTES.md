## Module <om_account_accountant>

#### 15.04.2022
#### Version 15.0.6.1.0
##### IMP
- merged diff PR's and remove create option for payment method menu

#### 15.04.2022
#### Version 15.0.6.0.0
##### IMP
- arabic translation and payment state update

#### 15.04.2022
#### Version 15.0.5.1.0
##### IMP
- turkish translation

#### 03.03.2022
#### Version 15.0.5.0.0
##### IMP
- daily report and followup added to dependency

#### 02.03.2022
#### Version 15.0.4.2.0
##### IMP
- update index file

#### 27.02.2022
#### Version 15.0.4.1.0
##### IMP
- moved excel report download link to accounting_pdf_reports module

#### 25.02.2022
#### Version 15.0.4.0.0
##### IMP
- credit limit

#### 17.12.2021
#### Version 15.0.3.1.0
##### IMP
- journal items menu visible in debug mode only, make it visible always

#### 12.12.2021
#### Version 15.0.3.0.0
##### IMP
- reconciliation, payment method name and user group name updates

#### 07.12.2021
#### Version 15.0.2.3.0
##### IMP
- coa and fiscal position templates

#### 07.12.2021
#### Version 15.0.2.2.0
##### ADD
- sale receipts and purchase receipts

