from . import res_partner
from . import res_company
from . import account_move
from . import sale_order
from . import res_config_settings
