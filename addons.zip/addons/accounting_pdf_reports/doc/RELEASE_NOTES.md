## Module <accounting_pdf_reports>

#### 15.04.2022
#### Version 15.0.8.1.0
##### IMP
- journal entry report total decimal

#### 15.04.2022
#### Version 15.0.8.0.0
##### IMP
- report filter

#### 15.04.2022
#### Version 15.0.7.6.0
##### IMP
- turkish translation

#### 11.04.2022
#### Version 15.0.7.5.0
##### IMP
- tax report

#### 11.03.2022
#### Version 15.0.7.4.0
##### FIX
- general ledger filter

#### 11.03.2022
#### Version 15.0.7.3.0
##### REV
- dynamic report download link

#### 28.02.2022
#### Version 15.0.7.2.0
##### REV
- pre init hook removed due to reported errors

#### 27.02.2022
#### Version 15.0.7.1.0
##### IMP
- report download links

#### 27.02.2022
#### Version 15.0.7.0.0
##### IMP
- refactoring code

#### 25.02.2022
#### Version 15.0.6.4.0
##### IMP
- pre_init_hook to clean up m2m data's


#### 25.02.2022
#### Version 15.0.6.3.0
##### IMP
- remove deprecated warning of currency conversion

#### 22.02.2022
#### Version 15.0.6.2.0
##### FIX
- aged partner with respect to changes in odoo core accounting

#### 01.02.2022
#### Version 15.0.6.1.0
##### IMP
- translation de

#### 25.12.2021
#### Version 15.0.6.0.0
##### IMP
- filters like account, partner and analytic account

#### 14.12.2021
#### Version 15.0.5.0.0
##### IMP
- remove logger warning, same label
